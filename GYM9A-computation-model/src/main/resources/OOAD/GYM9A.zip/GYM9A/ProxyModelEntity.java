package com.ted.app;

public class ProxyModelEntity implements Model{

    private String name;

    private ModelEntity modelEntity;

    public ProxyModelEntity(String name) {
        this.name = name;
    }

    @Override
    public Double[] linearTransformation(Double[] vector) {

        if(modelEntity == null){
            modelEntity = new ModelEntity(name);
        }

        return modelEntity.linearTransformation(vector);
    }
}
