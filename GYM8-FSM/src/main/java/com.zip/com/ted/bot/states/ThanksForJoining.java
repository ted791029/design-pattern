package com.ted.bot.states;

import com.ted.fsm.Action;
import com.ted.fsm.State;
import com.ted.fsm.Transition;

import java.util.List;
import java.util.Map;

public class ThanksForJoining extends KnowledgeKing {
    public ThanksForJoining(State initial, List<Transition> transitions, Map<String, String> resultMap, Action enter, Action exit, Map<String, Integer> scoreMap) {
        super(initial, transitions, resultMap, enter, exit, scoreMap);
    }
}
