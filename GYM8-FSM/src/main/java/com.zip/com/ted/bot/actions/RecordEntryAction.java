package com.ted.bot.actions;

import com.google.gson.JsonObject;
import com.ted.bot.states.Record;
import com.ted.fsm.Action;
import com.ted.fsm.Context;
import com.ted.fsm.Event;
import com.ted.util.JsonUtil;

public class RecordEntryAction implements Action {

    @Override
    public void execute(Context context) {
        Record record = (Record) context.getState();
        Event event = context.getEvent();
        initRecordId(record, event);
        record.setCurrent(record.getInitial());
    }

    private void initRecordId(Record record, Event event){
        String payload = event.getPayload();
        JsonObject userObj = JsonUtil.toJsonObject(JsonUtil.get("user", payload));
        String userId = JsonUtil.get("id", userObj.toString());
        record.setRecorderIdVal(userId);
    }
}
