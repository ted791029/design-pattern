package com.ted;

public class Main {

    public static void main(String[] args) throws InterruptedException {

    }

}
