package com.ted.bot.states;

import com.ted.bot.Id;
import com.ted.fsm.Action;
import com.ted.fsm.Context;
import com.ted.fsm.State;
import com.ted.fsm.Transition;

import java.util.List;
import java.util.Map;

public class Record extends State {

    private Id recorderId;

    public Record(State initial, List<Transition> transitions, Map<String, String> resultMap, Action enter, Action exit, Id recorderId) {
        super(initial, transitions, resultMap, enter, exit);
        this.recorderId = recorderId;
    }

    public String getRecorderIdVal(){
        return recorderId.getVal();
    }

    @Override
    public void response(Context context) {

    }

    public void setRecorderIdVal(String id){
        recorderId.setVal(id);
    }

    //=============================================

    public Id getRecorderId() {
        return recorderId;
    }

    public void setRecorderId(Id recorderId) {
        this.recorderId = recorderId;
    }
}
