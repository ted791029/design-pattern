package com.ted.bot.states;

import com.google.gson.JsonObject;
import com.ted.bot.BotEventResult;
import com.ted.bot.StateResponseHandler;
import com.ted.fsm.Action;
import com.ted.fsm.Context;
import com.ted.fsm.State;
import com.ted.fsm.Transition;

import java.util.*;

public class Questioning extends KnowledgeKing {
    private String[] questions = {
            "請問哪個 SQL 語句用於選擇所有的行？\nA) SELECT *\nB) SELECT ALL\nC) SELECT ROWS\nD) SELECT DATA",
            "請問哪個 CSS 屬性可用於設置文字的顏色？ \nA) text-align \nB) font-size \nC) color \nD) padding",
            "請問在計算機科學中，「XML」代表什麼？ \nA) Extensible Markup Language\nB) Extensible Modeling Language\nC) Extended Markup Language\nD) Extended Modeling Language"
    };

    private String[] answer = {"A", "C", "A"};

    private int index;

    private boolean isNotMoreQuestion = false;

    private long overTime = 60 * 60 * 1000;

    private final String tagBot = "bot";

    private Timer timer = new Timer();

    private long startTime;

    private StateResponseHandler stateResponseHandler;

    public Questioning(State initial, List<Transition> transitions, Map<String, String> resultMap, Action enter, Action exit, Map<String, Integer> scoreMap, StateResponseHandler stateResponseHandler) {
        super(initial, transitions, resultMap, enter, exit, scoreMap);
        this.stateResponseHandler = stateResponseHandler;

    }

    public void initTimer() {
        initStartTime();
        initTimerTask();
    }

    public void addCorrecterScore(String userId){
        Map<String, Integer> scoreMap = getScoreMap();
        int score = scoreMap.getOrDefault(userId, 0);
        scoreMap.put(userId, ++score);
    }

    public void addIndex() {
        index++;
    }

    public void elapsed(long time) {
        setOverTime(overTime - time);
    }

    public String generateQuestion() {
        return questions[index];
    }

    public void generateQuestionEventResult(Context context) {
        //🤖: 0. 請問哪個 SQL 語句用於選擇所有的行？
        //A) SELECT *
        //B) SELECT ALL
        //C) SELECT ROWS
        //D) SELECT DATA
        JsonObject jsonObject = new JsonObject();
        Questioning questioning = (Questioning) context.getState();
        String content = questioning.getIndex() + ". " + questioning.generateQuestion();
        jsonObject.addProperty("content", content);
        String result = jsonObject.toString();
        context.addEventResult(BotEventResult.BOT_GENERATE_QUESTION.getName(), result);
    }


    public String getWinner(){
        Map<String, Integer> scoreMap = getScoreMap();
        int highestScore = 0;
        List<String> winners = new ArrayList<>();

        for(String id : scoreMap.keySet()){
            int score = scoreMap.get(id);

            if(score > highestScore){
                highestScore = score;
                winners = new ArrayList<>();
                winners.add(id);
            }else if(score == highestScore){
                winners.add(id);
            }
        }

        return winners.size() == 1 ? winners.get(0) : null;
    }

    public boolean isEnd(){
        return isNotMoreQuestion || isOverTime();
    }

    public void resetIndex() {
        index = 0;
    }


    @Override
    public void response(Context context) {
        stateResponseHandler.handle(context);
    }

    private void initStartTime() {
        this.startTime = System.currentTimeMillis();
    }

    private void initTimerTask() {
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                //發送超時事件
            }
        };

        timer.schedule(task, overTime);
    }

    private boolean isOverTime(){
        long now = System.currentTimeMillis();
        boolean isOvertime =  (now - startTime) >= overTime;
        return isOvertime;
    }

    //======================


    public String[] getQuestions() {
        return questions;
    }

    public void setQuestions(String[] questions) {
        this.questions = questions;
    }

    public String[] getAnswer() {
        return answer;
    }

    public void setAnswer(String[] answer) {
        this.answer = answer;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public boolean isNotMoreQuestion() {
        return isNotMoreQuestion;
    }

    public void setNotMoreQuestion(boolean notMoreQuestion) {
        isNotMoreQuestion = notMoreQuestion;
    }

    public long getOverTime() {
        return overTime;
    }

    public void setOverTime(long overTime) {

        if (overTime <= 0) {
            this.overTime = 0;
            return;
        }

        this.overTime = overTime;
    }

    public String getTagBot() {
        return tagBot;
    }

    public Timer getTimer() {
        return timer;
    }

    public void setTimer(Timer timer) {
        this.timer = timer;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public StateResponseHandler getStateResponseHandler() {
        return stateResponseHandler;
    }

    public void setStateResponseHandler(StateResponseHandler stateResponseHandler) {
        this.stateResponseHandler = stateResponseHandler;
    }
}
