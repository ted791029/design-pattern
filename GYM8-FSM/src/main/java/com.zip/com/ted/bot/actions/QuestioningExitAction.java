package com.ted.bot.actions;

import com.ted.fsm.Action;
import com.ted.fsm.Context;

public class QuestioningExitAction implements Action {
    @Override
    public void execute(Context context) {

    }
}
